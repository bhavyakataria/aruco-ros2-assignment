#!/usr/bin/env python3

import argparse
import sys
import time

import cv2
import rclpy
from rclpy.node import Node

from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from aruco_interfaces.srv import DetectAruco
from aruco_interfaces.msg import Marker


class ArucoClient(Node):
    def __init__(self, video_path=None):
        super().__init__('aruco_client')
        

        self.declare_parameter('video_path', video_path or '')
        self.video_path = self.get_parameter('video_path').value
        
        self.bridge = CvBridge()
        
        self.client = self.create_client(DetectAruco, 'detect_aruco')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for detect_aruco service...')
        
        self.get_logger().info(f'ArucoClient ready. Using: {"video" if not self.video_path else self.video_path}')
        
        if self.video_path:
            self.cap = cv2.VideoCapture(self.video_path)
        else:
            self.cap = cv2.VideoCapture(0)  
        
        if not self.cap.isOpened():
            self.get_logger().error('Cannot open video')
            return
        
        self.timer = self.create_timer(0.1, self.timer_callback)  # 10 FPS

    def timer_callback(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn('Failed to grab frame')
            return

        self.get_logger().info(f'Captured frame: {frame.shape}')

        # Convert frame to ROS Image message
        img_msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        self.get_logger().info(f'Image msg: {len(img_msg.data)} bytes, {img_msg.width}x{img_msg.height}')
    
        # Create service request
        request = DetectAruco.Request()
        request.image = img_msg
    
        # Call service asynchronously
        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
    
        if future.result() is not None:
            response = future.result()
            self.print_markers(response.markers)
        else:
            self.get_logger().error('Service call failed')

    def print_markers(self, markers):
        if not markers:
            self.get_logger().info('No markers detected')
            return
        
        self.get_logger().info(f'Detected {len(markers)} markers:')
        for i, marker in enumerate(markers):
            bbox_str = f'[{marker.bbox[0]},{marker.bbox[1]} {marker.bbox[2]},{marker.bbox[3]} '
            bbox_str += f'{marker.bbox[4]},{marker.bbox[5]} {marker.bbox[6]},{marker.bbox[7]}]'
            self.get_logger().info(f'  Marker {i}: ID={marker.id}, corners={bbox_str}')

    def destroy_node(self):
        self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--video', default=None, help='Path to video file')
    args_parsed = parser.parse_args()
    
    node = ArucoClient(video_path=args_parsed.video)
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()


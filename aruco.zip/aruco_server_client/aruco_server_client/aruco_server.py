
import cv2
import numpy as np

import rclpy
from rclpy.node import Node

from cv_bridge import CvBridge

from sensor_msgs.msg import Image
from aruco_interfaces.srv import DetectAruco   
from aruco_interfaces.msg import Marker       


class ArucoServer(Node):

    def __init__(self):
        super().__init__('aruco_server')

        self.srv = self.create_service(
            DetectAruco,
            'detect_aruco',
            self.detect_aruco_callback
        )

       
        self.bridge = CvBridge()

        self.aruco_dict = cv2.aruco.getPredefinedDictionary(
            cv2.aruco.DICT_4X4_100
        )
        self.parameters = cv2.aruco.DetectorParameters()

        self.get_logger().info('ArucoServer ready: service "detect_aruco"')

    def detect_aruco_callback(self, request, response):
        if request.image.data is None or len(request.image.data) == 0:
            self.get_logger().warn('Empty image received')
            response.markers = []
            return response
    
        try:
            frame = self.bridge.imgmsg_to_cv2(request.image, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'Failed to convert image: {e}')
            response.markers = []
            return response


        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        detector = cv2.aruco.ArucoDetector(self.aruco_dict, self.parameters)

        corners, ids, rejected = detector.detectMarkers(gray)

        markers_msg = []

        if ids is not None and len(ids) > 0:
            ids = ids.flatten()

            for marker_corners, marker_id in zip(corners, ids):
                pts = marker_corners.reshape((4, 2))

                (top_left, top_right, bottom_right, bottom_left) = pts

                tl = (int(top_left[0]), int(top_left[1]))
                tr = (int(top_right[0]), int(top_right[1]))
                br = (int(bottom_right[0]), int(bottom_right[1]))
                bl = (int(bottom_left[0]), int(bottom_left[1]))

                bbox_flat = [
                    tl[0], tl[1],
                    tr[0], tr[1],
                    br[0], br[1],
                    bl[0], bl[1],
                ]

                marker_msg = Marker()
                marker_msg.id = int(marker_id)
                marker_msg.bbox = bbox_flat

                markers_msg.append(marker_msg)

        response.markers = markers_msg

        self.get_logger().info(f'Detected {len(markers_msg)} markers')

        return response


def main(args=None):
    rclpy.init(args=args)
    node = ArucoServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
